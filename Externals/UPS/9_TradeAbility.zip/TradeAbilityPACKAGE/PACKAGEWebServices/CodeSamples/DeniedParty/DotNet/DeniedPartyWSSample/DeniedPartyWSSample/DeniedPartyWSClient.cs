using System;
using System.Collections.Generic;
using System.Text;
using DeniedPartyWSSample.DeniedPartyWebReference;


namespace DeniedPartyWSSample
{
    class DeniedPartyWSClient
    {
        static void Main()
        {
            DPS denidedPartyService = new DPS();
            DeniedPartyScreenerRequest dpsRequest = new DeniedPartyScreenerRequest();
            RequestTransportType requestType = new RequestTransportType();
            requestType.RequestAction="DeniedPartyScreener";
            dpsRequest.Request = requestType;

            PartyType partyType = new PartyType();
            partyType.ScreenType = "Party";
            //partyType.CompanyName = "Required company name";
            partyType.CompanyName = "Taliban";

            AddressType addressType = new AddressType();       
            String[] addressLine = { "Required address line" };
            //String[] addressLine = { "38313 Hardin Hill Ave" };
          
            addressType.AddressLine=addressLine;
            partyType.Address=addressType;
            dpsRequest.Party=partyType;

            AccessRequest accessRequest = new AccessRequest();
            accessRequest.UserId = "Your user id";
            accessRequest.Password = "Your password";
            accessRequest.AccessLicenseNumber = "Your access license number";

            
            denidedPartyService.AccessRequestValue = accessRequest;
            
            System.Net.ServicePointManager.CertificatePolicy = new TrustAllCertificatePolicy();
            
            Console.WriteLine("----Start Request ToString---------------------");
            Console.WriteLine(dpsRequest.ToString());
            Console.WriteLine("-----End Request ToString--------------------");
            Console.WriteLine("");
        
            try{
                
                Console.WriteLine("-----Start DeniedPartyScreenerResponse Process--------------------");
                DeniedPartyScreenerResponse deniedPartyResponse = denidedPartyService.ProcessDPSRequest(dpsRequest);
                Console.WriteLine("This is a success transaction=" + deniedPartyResponse.Response.ToString());

                GovernmentListType[] valSet = deniedPartyResponse.GovernmentList;
                Console.WriteLine("Total on GovernmentList = " +valSet.Length);

                GovernmentListType aGov =valSet[0];
                GovernmentListTypeDeniedParty[] apartyList=  aGov.DeniedParty;
                Console.WriteLine("Total number of Denied party on GovernmentList = " +apartyList.Length);
                GovernmentListTypeDeniedParty adeniedP = apartyList[0];
                Console.WriteLine("NameOfThisParty="+adeniedP.Names);
                Console.WriteLine("RemarkOfThisParty="+adeniedP.Remarks);
             
                Console.WriteLine("-------------------------");
                Console.WriteLine("");
            }
            catch (System.Web.Services.Protocols.SoapException ex)
            {
                Console.WriteLine("");
                Console.WriteLine("---------DeniedPartyScreener Web Service returns error----------------");
                Console.WriteLine("---------\"Hard\" is user error \"Transient\" is system error----------------");
                Console.WriteLine("SoapException Message= " + ex.Message);
                Console.WriteLine("");
                Console.WriteLine("SoapException Category:Code:Message= " + ex.Detail.LastChild.InnerText);
                Console.WriteLine("");
                Console.WriteLine("SoapException XML String for all= " + ex.Detail.LastChild.OuterXml);
                Console.WriteLine("");
                Console.WriteLine("SoapException StackTrace= " + ex.StackTrace);
                Console.WriteLine("-------------------------");
                Console.WriteLine("");
            }
            catch (Exception ex)
            {
                Console.WriteLine("");
                Console.WriteLine("-------------------------");
                Console.WriteLine(" Generaal Exception= " + ex.Message);
                Console.WriteLine(" Generaal Exception-StackTrace= " + ex.StackTrace);
                Console.WriteLine("-------------------------");

            }
            finally
            {
                Console.ReadKey();
            }

         

        }
    }
}

