<?php

  //Configuration
  $access = " Add License Key Here";
  $userid = " Add User Id Here";
  $passwd = " Add Password Here";
  $wsdl = " Add Wsdl File Here ";
  $operation = "ProcessELDRequest";
  $endpointurl = ' Add URL Here';
  $outputFileName = "XOLTResult.xml";

  function processELDRequest()
  {
      //create soap request
      $action['RequestAction'] = 'ExportLicenseDetection';
      $request['Request'] = $action;

      $request['ShipToCountryCode'] = 'BE';
      $product = array
      (
           array
           (
               'ECCN' => '9A116',
               'Quantity' => array
               (
                   'UnitOfMeasure' => array
                   (
                       'UnitCode' => 'KGS',
                       'UnitDescription' => 'Kilograms'
                   ),
                   'Value' => '1'
               ),
               'ValuePerUnit' => array
	           (
	        	   'MonetaryValue' => '1',
	        	   'CurrencyCode' => 'HKD'
	           )
           )
      );
      $request['Product'] = $product;

      echo "Request.......\n";
      print_r($request);
      echo "\n\n";
      return $request;
  }

  try
  {

    $mode = array
    (
         'soap_version' => 'SOAP_1_1',  // use soap 1.1 client
         'trace' => 1
    );

    // initialize soap client
  	$client = new SoapClient($wsdl , $mode);

  	//set endpoint url
  	$client->__setLocation($endpointurl);


    //create soap header
    $auth['UserId'] = $userid;
    $auth['Password'] = $passwd;
    $auth['AccessLicenseNumber'] = $access;


    $header = new SoapHeader('http://www.ups.com/schema/xpci/1.0/auth','AccessRequest',$auth);
    $client->__setSoapHeaders($header);


    //get response
  	$resp = $client->__soapCall($operation ,array(processELDRequest()));

    //get status
    echo "Response Status: ". $resp->Results->Notes->Note . "\n";

    //save soap request and response to file
    $fw = fopen($outputFileName , 'w');
    fwrite($fw , "Request: \n" . $client->__getLastRequest() . "\n");
    fwrite($fw , "Response: \n" . $client->__getLastResponse() . "\n");
    fclose($fw);

  }
  catch(Exception $ex)
  {
  	print_r ($ex);
  }

?>
