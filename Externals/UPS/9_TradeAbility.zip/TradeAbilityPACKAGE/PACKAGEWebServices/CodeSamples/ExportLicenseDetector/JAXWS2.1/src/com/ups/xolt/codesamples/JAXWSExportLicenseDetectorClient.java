/* 
 ** 
 ** Filename: JAXWSExportLicenseDetectorClient.java 
  ** Authors: United Parcel Service of America
 ** 
 ** The use, disclosure, reproduction, modification, transfer, or transmittal 
 ** of this work for any purpose in any form or by any means without the 
 ** written permission of United Parcel Service is strictly prohibited. 
 ** 
 ** Confidential, Unpublished Property of United Parcel Service. 
 ** Use and Distribution Limited Solely to Authorized Personnel. 
 ** 
 ** Copyright 2009 United Parcel Service of America, Inc.  All Rights Reserved. 
 ** 
 */
package com.ups.xolt.codesamples;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.util.Calendar;
import java.util.List;
import java.util.Properties;

import javax.xml.ws.BindingProvider;

import com.ups.schema.xpci._1_0.auth.AccessRequest;
import com.ups.schema.xpci._1_0.eld.ELD;
import com.ups.schema.xpci._1_0.eld.ELDRequestPortType;
import com.ups.schema.xpci._1_0.eld.Error;
import com.ups.schema.xpci._1_0.eld.ExportLicenseDetectionRequest;
import com.ups.schema.xpci._1_0.eld.ExportLicenseDetectionResponse;
import com.ups.schema.xpci._1_0.eld.ProductType;
import com.ups.schema.xpci._1_0.eld.RequestTransportType;
import com.ups.schema.xpci._1_0.eld.ValueWithCurrency;
import com.ups.schema.xpci._1_0.eld.ValueWithUnitsType;
import com.ups.schema.xpci._1_0.eld.ValueWithUnitsType.UnitOfMeasure;
import com.ups.schema.xpci._1_0.error.CodeType;
import com.ups.schema.xpci._1_0.error.ErrorDetailType;
import com.ups.schema.xpci._1_0.error.Errors;

public class JAXWSExportLicenseDetectorClient {
	
	private static String accesskey;
	private static String username;
	private static String password;
	private static String out_file_location = "out_file_location";
	private static String tool_or_webservice_name = "tool_or_webservice_name";
	private static final String url = "url";
	static Properties props = null;
	static{
        try{
        	props = new Properties();
        	props.load(new FileInputStream("./build.properties"));
	  		accesskey = props.getProperty("accesskey");
	  		username = props.getProperty("username");
	  		password = props.getProperty("password");
        }
        catch(Exception e){
        	e.printStackTrace();
        }
	}
	public static void main(String args[])throws Exception {
		String statusCode = null;
		String description = null;
    try {
     	ELD eldService = new ELD();
		ELDRequestPortType eldPort = eldService.getELDRequestPortTypePort();
		BindingProvider bp = (BindingProvider)eldPort;
    	
    	bp.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, props.getProperty(url));
    	System.out.println("url...."+eldPort);
		ExportLicenseDetectionRequest eldRequest = new ExportLicenseDetectionRequest();
		RequestTransportType requestTransType = new RequestTransportType();
		requestTransType.setRequestAction("ExportLicenseDetection");
		eldRequest.setRequest(requestTransType);
		eldRequest.setShipToCountryCode("BE");
		
		List<ProductType> productType =eldRequest.getProduct() ;
		ProductType aprodType = new ProductType();
		aprodType.setECCN("9A116");
		ValueWithUnitsType quantity = new ValueWithUnitsType();
		UnitOfMeasure measure = new UnitOfMeasure();
		measure.setUnitCode("KGS");
		measure.setUnitDescription("Kilograms");
		quantity.setUnitOfMeasure(measure);
		quantity.setValue(1);
		aprodType.setQuantity(quantity);
		ValueWithCurrency currency = new ValueWithCurrency();
		currency.setCurrencyCode("HKD");
		currency.setMonetaryValue("1");
		aprodType.setValuePerUnit(currency);
		productType.add(aprodType);

			
		/**************UPSSE***************************/
		AccessRequest upss = new AccessRequest();
		upss.setUserId(username);
		upss.setPassword(password);
    	upss.setAccessLicenseNumber(accesskey);
     	/**************UPSSE******************************/
		ExportLicenseDetectionResponse eldResponse = eldPort.processELDRequest(eldRequest, upss);
		//statusCode = eldResponse.getResponse().toString();
		updateResultsToFile(statusCode, description);
		System.out.println("Transaction Status: " + eldResponse.getTransactionInfo().getDate());

	} catch (Error avE) {
		Errors errs= avE.getFaultInfo();
		List<ErrorDetailType> errDetailList = errs.getErrorDetail();
		ErrorDetailType aError = errDetailList.get(0);
		
		CodeType primaryError = aError.getPrimaryErrorCode();
		description = primaryError.getDescription();			
		statusCode = primaryError.getCode();
		updateResultsToFile(statusCode, description);
		System.out.println("\nThe Error Response: Code=" +statusCode + " Decription=" + description);
		

	}catch (Exception e) {
		description=e.getMessage();
		statusCode=e.toString();
		updateResultsToFile(statusCode, description);
		e.printStackTrace();
		}
	}
	/**
     * This method updates the XOLTResult.xml file with the received status and description
     * @param statusCode
     * @param description
     */
	private static void updateResultsToFile(String statusCode, String description){
    	BufferedWriter bw = null;
    	try{    		
     		File outFile = new File(props.getProperty(out_file_location));
    		System.out.println("Output file deletion status: " + outFile.delete());
    		outFile.createNewFile();
    		System.out.println("Output file location: " + outFile.getCanonicalPath());
    		bw = new BufferedWriter(new FileWriter(outFile));
    		StringBuffer strBuf = new StringBuffer();
    		strBuf.append("<ExecutionAt>");
    		strBuf.append(Calendar.getInstance().getTime());
    		strBuf.append("</ExecutionAt>\n");
    		strBuf.append("<ToolOrWebServiceName>");
    		strBuf.append(props.getProperty(tool_or_webservice_name));
    		strBuf.append("</ToolOrWebServiceName>\n");
    		strBuf.append("\n");
    		strBuf.append("<ResponseStatus>\n");
    		strBuf.append("\t<Code>");
    		strBuf.append(statusCode);
    		strBuf.append("</Code>\n");
    		strBuf.append("\t<Description>");
    		strBuf.append(description);
    		strBuf.append("</Description>\n");
    		strBuf.append("</ResponseStatus>");
    		bw.write(strBuf.toString());
    		bw.close();    		    		
    	}catch (Exception e) {
			e.printStackTrace();
		}finally{
			try{
				if (bw != null){
					bw.close();
					bw = null;
				}
			}catch (Exception e) {
				e.printStackTrace();
			}			
		}		
    }
	
}
