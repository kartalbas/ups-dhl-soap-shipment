using System;
using System.Collections.Generic;
using System.Text;
using ExportLicenseDetectorWSSample.ExportLicenseWebReference;

namespace ExportLicenseDetectorWSSample
{
    class ExportLicenseDetectorClient
    {
        static void Main()
        {
            ELD eldService = new ELD();
            ExportLicenseDetectionRequest eldRequest = new ExportLicenseDetectionRequest();

            RequestTransportType request = new RequestTransportType();
            request.RequestAction="ExportLicenseDetection";
            eldRequest.Request=request;
            eldRequest.ShipToCountryCode="ShipTo country code";
          

            ProductType[] productType = new ProductType[1];
            ProductType prodType = new ProductType();
           prodType.ECCN="Required ECCN";
          
            ValueWithUnitsType quantity = new ValueWithUnitsType();
            ValueWithUnitsTypeUnitOfMeasure measure = new ValueWithUnitsTypeUnitOfMeasure();
            
            //Below code uses dummy data for reference purpose. Please update as required.           
            measure.UnitCode="KGS";
            measure.UnitDescription="Kilograms";
            quantity.UnitOfMeasure=measure;
            quantity.Value=1;
            prodType.Quantity=quantity;
            ValueWithCurrency currency = new ValueWithCurrency();
            currency.CurrencyCode="HKD";
            currency.MonetaryValue="1";
            prodType.ValuePerUnit=currency;
            productType[0] = prodType;
            eldRequest.Product=productType;

            AccessRequest accessRequest = new AccessRequest();
            accessRequest.UserId = "Your user id";
            accessRequest.Password = "Your password";
            accessRequest.AccessLicenseNumber = "Your access license number";
           

            eldService.AccessRequestValue = accessRequest;

            System.Net.ServicePointManager.CertificatePolicy = new TrustAllCertificatePolicy();

            Console.WriteLine("----Start Request ToString---------------------");
            Console.WriteLine(eldRequest.ToString());
            Console.WriteLine("-----End Request ToString--------------------");
            Console.WriteLine("");

            try
            {

                Console.WriteLine("-----Start Response Process--------------------");
                ExportLicenseDetectionResponse eldResponse = eldService.ProcessELDRequest(eldRequest);
                Console.WriteLine("This is a success transaction=" + eldResponse.Response.ToString());

                LDResultType[] rstSet = eldResponse.Results;
                Console.WriteLine("Total on Result List = " + rstSet.Length);

                LDResultType aRest = rstSet[0];
                NotesType[] noteList = aRest.Notes;
                Console.WriteLine("Total number of  Notes = " + noteList.Length);
                NotesType aNote = noteList[0];

                Console.WriteLine("NoteCode=" + aNote.ID);
                Console.WriteLine("Note Text=" + aNote.Note);

                Console.WriteLine("-------------------------");
                Console.WriteLine("");
            }
            catch (System.Web.Services.Protocols.SoapException ex)
            {
                Console.WriteLine("");
                Console.WriteLine("---------ExportLicenseDetector Web Service returns error----------------");
                Console.WriteLine("---------\"Hard\" is user error \"Transient\" is system error----------------");
                Console.WriteLine("SoapException Message= " + ex.Message);
                Console.WriteLine("");
                Console.WriteLine("SoapException Category:Code:Message= " + ex.Detail.LastChild.InnerText);
                Console.WriteLine("");
                Console.WriteLine("SoapException XML String for all= " + ex.Detail.LastChild.OuterXml);
                Console.WriteLine("");
                Console.WriteLine("SoapException StackTrace= " + ex.StackTrace);
                Console.WriteLine("-------------------------");
                Console.WriteLine("");
            }
            catch (Exception ex)
            {
                Console.WriteLine("");
                Console.WriteLine("-------------------------");
                Console.WriteLine(" Generaal Exception= " + ex.Message);
                Console.WriteLine(" Generaal Exception-StackTrace= " + ex.StackTrace);
                Console.WriteLine("-------------------------");

            }
            finally
            {
                Console.ReadKey();
            }

        }
    }
}

