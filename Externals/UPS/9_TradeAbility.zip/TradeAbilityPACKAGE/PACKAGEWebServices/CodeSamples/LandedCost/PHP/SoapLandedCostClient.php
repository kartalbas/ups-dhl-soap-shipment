<?php

  //Configuration
  $access = " Add License Key Here";
  $userid = " Add User Id Here";
  $passwd = " Add Password Here";
  $wsdl = " Add Wsdl File Here ";
  $operation = "ProcessLCRequest";
  $endpointurl = ' Add URL Heret';
  $outputFileName = "XOLTResult.xml";

  function processLCRequest()
  {
      //create soap request
      $action['RequestAction'] = 'LandedCost';
      $request['Request'] = $action;

      $queryrequest = array
      (
           'Shipment' => array
	       (
	    		'OriginCountryCode' => 'US',
	    		'DestinationCountryCode' => 'CY',
	    		'TransportationMode' => '1',
	    		'ResultCurrencyCode' => 'EUR',
	    		'FreightCharges' => array
	    		(
	    			'MonetaryValue' => '10',
	    			'CurrencyCode' => 'EUR'
	    		),

	    		'AdditionalInsurance' => array
	    		(
	    			'MonetaryValue' => '10',
	    			'CurrencyCode' => 'EUR'
	    		),

	    		'Product' => array
	    		(
	    		    array
	    		    (
	    		    	'TariffInfo' => array
	    		    	(
	    		    		'TariffCode' => '4901990000',
	    		    	),

	    		    	'Quantity' => array
	    		    	(
	    		    		'Value' => '5'
	    		    	),

	    		    	'UnitPrice' => array
	    		    	(
	    		    		'MonetaryValue' => '5.5',
	    		    		'CurrencyCode' => 'USD'
	    		    	)
	    		    )
	    		)
	    	)
      );
      $request['QueryRequest'] = $queryrequest;

      echo "Request.......\n";
      print_r($request);
      echo "\n\n";
      return $request;
  }

  try
  {

    $mode = array
    (
         'soap_version' => 'SOAP_1_1',  // use soap 1.1 client
         'trace' => 1
    );

    // initialize soap client
  	$client = new SoapClient($wsdl , $mode);

  	//set endpoint url
  	$client->__setLocation($endpointurl);


    //create soap header
    $auth['UserId'] = $userid;
    $auth['Password'] = $passwd;
    $auth['AccessLicenseNumber'] = $access;


    $header = new SoapHeader('http://www.ups.com/schema/xpci/1.0/auth','AccessRequest',$auth);
    $client->__setSoapHeaders($header);


    //get response
  	$resp = $client->__soapCall($operation ,array(processLCRequest()));

    //get status
    echo "Transaction Digest: ". $resp->QueryResponse->TransactionDigest . "\n";

    //save soap request and response to file
    $fw = fopen($outputFileName , 'w');
    fwrite($fw , "Request: \n" . $client->__getLastRequest() . "\n");
    fwrite($fw , "Response: \n" . $client->__getLastResponse() . "\n");
    fclose($fw);

  }
  catch(Exception $ex)
  {
  	print_r ($ex);
  }

?>
