using System;
using System.Collections.Generic;
using System.Text;
using LandedCostWSSample.LandedCostWebReference;

namespace LandedCostWSSample
{
    class LandedCostWSClient
    {
        static void Main()
        {
            try
            {
                LC lc = new LC();
                LandedCostRequest lcRequest = new LandedCostRequest();
                QueryRequestType queryRequest = new QueryRequestType();
                ShipmentType shipType = new ShipmentType();

                //Below code uses dummy data for reference purpose. Please update as required.
                shipType.OriginCountryCode = "US";
                shipType.DestinationCountryCode = "CY";
                shipType.TransportationMode = "1";
                shipType.ResultCurrencyCode = "EUR";

                ChargesType freightChargeType = new ChargesType();
                freightChargeType.CurrencyCode = "EUR";
                freightChargeType.MonetaryValue = "10";
                shipType.FreightCharges = freightChargeType;

                ChargesType additionalInsurance = new ChargesType();
                additionalInsurance.CurrencyCode = "EUR";
                additionalInsurance.MonetaryValue = "10";
                shipType.AdditionalInsurance = additionalInsurance;

                ProductType prodType = new ProductType();
                prodType.ProductCountryCodeOfOrigin = "US";
                TariffInfoType teriffType = new TariffInfoType();
                teriffType.TariffCode = "4901990000";
                prodType.TariffInfo = teriffType;
                ChargesType unitPrice = new ChargesType();
                unitPrice.MonetaryValue = "5.5";
              
                unitPrice.CurrencyCode = "EUR";
                prodType.UnitPrice = unitPrice;
                ValueWithUnitsType quantity = new ValueWithUnitsType();
                quantity.Value = "5";
                prodType.Quantity = quantity;
                ProductType[] pType = new ProductType[1];
                pType[0] = prodType;
                shipType.Product = pType;
                shipType.ResultCurrencyCode = "EUR";
                queryRequest.Shipment = shipType;

                RequestTransportType requestTransType = new RequestTransportType();
                requestTransType.RequestAction = "LandedCost";
                lcRequest.Request = requestTransType;
                lcRequest.Item = queryRequest;


                AccessRequest accessRequest = new AccessRequest();
                accessRequest.UserId = "Your user id";
                accessRequest.Password = "Your password";
                accessRequest.AccessLicenseNumber = "Your access key";

               
                lc.AccessRequestValue = accessRequest;

                System.Net.ServicePointManager.CertificatePolicy = new TrustAllCertificatePolicy();

                //------------------------
                Console.WriteLine("----Start Request ToString---------------------");
                Console.WriteLine(lcRequest.ToString());
                Console.WriteLine("-----End Request ToString--------------------");
                Console.WriteLine("");

                try
                {

                    Console.WriteLine("-----Start Response Process--------------------");
                    LandedCostResponse lcResponse = lc.ProcessLCRequest(lcRequest);
                    Console.WriteLine("This is a success transaction");


                    //Please note: only handles 1 response QueryResponse, not the EstimatedResponse here
                    
                    QueryResponseType queryResponse = (QueryResponseType)lcResponse.Item;
                    String questionName = queryResponse.Shipment.Product[0].Question[0].Name;
                    String questionText = queryResponse.Shipment.Product[0].Question[0].Text;

                    Console.WriteLine("The landedCostResponse : " + lcResponse.Response);
                    Console.WriteLine("Question name : " + questionName);
                    Console.WriteLine("Question Text: " + questionText);

                    Console.WriteLine("-------------------------");
                    Console.WriteLine("");
                }
                catch (System.Web.Services.Protocols.SoapException ex)
                {
                    Console.WriteLine("");
                    Console.WriteLine("---------ExportLicenseDetector Web Service returns error----------------");
                    Console.WriteLine("---------\"Hard\" is user error \"Transient\" is system error----------------");
                    Console.WriteLine("SoapException Message= " + ex.Message);
                    Console.WriteLine("");
                    Console.WriteLine("SoapException Category:Code:Message= " + ex.Detail.LastChild.InnerText);
                    Console.WriteLine("");
                    Console.WriteLine("SoapException XML String for all= " + ex.Detail.LastChild.OuterXml);
                    Console.WriteLine("");
                    Console.WriteLine("SoapException StackTrace= " + ex.StackTrace);
                    Console.WriteLine("-------------------------");
                    Console.WriteLine("");
                }
                catch (Exception ex)
                {
                    Console.WriteLine("");
                    Console.WriteLine("-------------------------");
                    Console.WriteLine(" Generaal Exception= " + ex.Message);
                    Console.WriteLine(" Generaal Exception-StackTrace= " + ex.StackTrace);
                    Console.WriteLine("-------------------------");

                }
                finally
                {
                    Console.ReadKey();
                }




            }

             catch (System.Web.Services.Protocols.SoapException ex)
            {
                Console.WriteLine("");
                Console.WriteLine("---------LandedCost Web Service returns error----------------");
                Console.WriteLine("---------\"Hard\" is user error \"Transient\" is system error----------------");
                Console.WriteLine("SoapException Message= " + ex.Message);
                Console.WriteLine("");
                Console.WriteLine("SoapException Category:Code:Message= " + ex.Detail.LastChild.InnerText);
                Console.WriteLine("");
                Console.WriteLine("SoapException XML for all= " + ex.Detail.LastChild.OuterXml);
                Console.WriteLine("");
                Console.WriteLine("SoapException StackTrace= " + ex.StackTrace);
                Console.WriteLine("-------------------------");
                Console.WriteLine("");
            }
          
            catch (Exception ex)
            {
                Console.WriteLine("");
                Console.WriteLine("-------------------------");
                Console.WriteLine(" Generaal Exception= " + ex.Message);
                Console.WriteLine(" Generaal Exception-StackTrace= " + ex.StackTrace);
                Console.WriteLine("-------------------------");

            }
            finally
            {
                Console.ReadKey();
            }

        }
           
        }
    }


