 no warnings; # turn off warnings
 
 use XML::Compile::WSDL11;
 use XML::Compile::SOAP11;
 use XML::Compile::Transport::SOAPHTTP;
 use HTTP::Request;
 use HTTP::Response;
 use Data::Dumper;
 
 #Configuration
 $access = " Add License Key Here";
 $userid = " Add User Id Her";
 $passwd = " Add Password Here";
 $operation = "ProcessLCRequest";
 $endpointurl = " Add URL Here";
 $wsdlfile = " Add Wsdl File Here ";
 $schemadir = "Add Schema Location Here";
 $outputFileName = "XOLTResult.xml";
 
 sub processLCRequest
 {
 	my $request =
 	{
 		AccessRequest =>  
	  	{
		   UserId => $userid,
		   Password => $passwd,
		   AccessLicenseNumber => $access
	  	},
	    Request =>
	    {
	    	RequestAction => 'LandedCost'
	    },
	    QueryRequest =>
	    {
	    	Shipment =>
	    	{
	    		OriginCountryCode => 'US',
	    		DestinationCountryCode => 'CY',
	    		TransportationMode => '1',
	    		ResultCurrencyCode => 'EUR',
	    		FreightCharges =>
	    		{
	    			MonetaryValue => '10',
	    			CurrencyCode => 'EUR'
	    		},
	    		AdditionalInsurance =>
	    		{
	    			MonetaryValue => '10',
	    			CurrencyCode => 'EUR'
	    		},
	    		
	    		Product =>
	    		[
	    		    {
	    		    	TariffInfo =>
	    		    	{
	    		    		TariffCode => '4901990000',
	    		    	},
	    		    	Quantity =>
	    		    	{
	    		    		Value => '5'
	    		    	},
	    		    	UnitPrice =>
	    		    	{
	    		    		MonetaryValue => '5.5',
	    		    		CurrencyCode => 'USD'
	    		    	}
	    		    }
	    		],
	    		
	    	}
	    }
 	};
 	
 	return $request;
 }
 
 my $wsdl = XML::Compile::WSDL11->new( $wsdlfile );
 $wsdl->importDefinitions("$schemadir/LandedCostWebServiceSchema.xsd");
 $wsdl->importDefinitions("$schemadir/AccessRequestXPCI.xsd");
 $wsdl->importDefinitions("$schemadir/ErrorXPCI.xsd");
 my $operation = $wsdl->operation($operation);
 my $call = $operation->compileClient(endpoint => $endpointurl);
 #print $wsdl->explain ('ProcessLCRequest' , PERL => 'INPUT' , recurse => 1);
 ($answer , $trace) = $call->(processLCRequest() , 'UTF-8');	
 
 if($answer->{Fault})
 {
	print $answer->{Fault}->{faultstring} ."\n";
	print Dumper($answer);
	print "See XOLTResult.xml for details.\n";
		
	# Save Soap Request and Response Details
	open(fw,">$outputFileName");
	$trace->printRequest(\*fw);
	$trace->printResponse(\*fw);
	close(fw);
 }
 else
 {
	# Get Response Status Description
    print "Transaction Digest: " . $answer->{Body}->{QueryResponse}->{TransactionDigest}. "\n" ; 

    # Print Request and Response
    my $req = $trace->request();
 	print "Request: \n" . $req->content() . "\n";
	my $resp = $trace->response();
	print "Response: \n" . $resp->content();
		
	# Save Soap Request and Response Details
	open(fw,">$outputFileName");
	$trace->printRequest(\*fw);
	$trace->printResponse(\*fw);
	close(fw);
}
 