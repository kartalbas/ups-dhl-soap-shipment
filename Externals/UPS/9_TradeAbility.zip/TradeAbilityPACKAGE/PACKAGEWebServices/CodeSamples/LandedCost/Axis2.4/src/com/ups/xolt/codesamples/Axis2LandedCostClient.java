/* 
 ** 
 ** Filename: Axis2LandedCostClient.java 
 ** Authors: United Parcel Service of America
 ** 
 ** The use, disclosure, reproduction, modification, transfer, or transmittal 
 ** of this work for any purpose in any form or by any means without the 
 ** written permission of United Parcel Service is strictly prohibited. 
 ** 
 ** Confidential, Unpublished Property of United Parcel Service. 
 ** Use and Distribution Limited Solely to Authorized Personnel. 
 ** 
 ** Copyright 2011 United Parcel Service of America, Inc.  All Rights Reserved. 
 ** 
 */

package com.ups.xolt.codesamples;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.util.Calendar;
import java.util.Properties;

import com.ups.www.schema.xpci._1_0.lc.Error;
import com.ups.www.schema.xpci._1_0.lc.LCStub;
import com.ups.www.schema.xpci._1_0.lc.LCStub.CodeType;
import com.ups.www.schema.xpci._1_0.lc.LCStub.ErrorDetailType;
import com.ups.www.schema.xpci._1_0.lc.LCStub.Errors;
import com.ups.www.schema.xpci._1_0.lc.LCStub.ProductResultType;
import com.ups.www.schema.xpci._1_0.lc.LCStub.QuestionType;

public class Axis2LandedCostClient {
	private static String url;
	private static String accesskey;
	private static String username;
	private static String password;
	private static String out_file_location = "out_file_location";
	private static String tool_or_webservice_name = "tool_or_webservice_name";
	static Properties props = null;
	static {
		try {
			props = new Properties();
			props.load(new FileInputStream("./build.properties"));
			url = props.getProperty("url");
			accesskey = props.getProperty("accesskey");
			username = props.getProperty("username");
			password = props.getProperty("password");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void main(String args[]) throws Exception {
		String statusCode = null;
		String description = null;
		try {
			LCStub lcStub = new LCStub(url);
			LCStub.LandedCostRequest lcRequest = new LCStub.LandedCostRequest();
			LCStub.LandedCostRequestChoice_type0 lcRequestChoiceType = new LCStub.LandedCostRequestChoice_type0();
			
			
			LCStub.QueryRequestType queryRequest = new LCStub.QueryRequestType();
			LCStub.ShipmentType shipType = new LCStub.ShipmentType();
			shipType.setOriginCountryCode("US");
			shipType.setDestinationCountryCode("CY");
			shipType.setTransportationMode("1");
			shipType.setResultCurrencyCode("EUR");

			LCStub.ChargesType freightChargeType = new LCStub.ChargesType();
			freightChargeType.setCurrencyCode("EUR");
			freightChargeType.setMonetaryValue("10");
			shipType.setFreightCharges(freightChargeType);
			LCStub.ChargesType additionalInsurance = new LCStub.ChargesType();
			additionalInsurance.setCurrencyCode("EUR");
			additionalInsurance.setMonetaryValue("10");
			shipType.setAdditionalInsurance(additionalInsurance);

			LCStub.ProductType prodType = new LCStub.ProductType();
			prodType.setProductCountryCodeOfOrigin("US");
			LCStub.TariffInfoType teriffType = new LCStub.TariffInfoType();
			teriffType.setTariffCode("4901990000");
			prodType.setTariffInfo(teriffType);
			LCStub.ChargesType unitPrice = new LCStub.ChargesType();
			unitPrice.setMonetaryValue("5.5");
			unitPrice.setCurrencyCode("USD");
			prodType.setUnitPrice(unitPrice);
			LCStub.ValueWithUnitsType quantity = new LCStub.ValueWithUnitsType();
			quantity.setValue("5");
			prodType.setQuantity(quantity);
			LCStub.ProductType[] pType = new LCStub.ProductType[1];
			pType[0] = prodType;

			shipType.setProduct(pType);
			shipType.setResultCurrencyCode("EUR");
			queryRequest.setShipment(shipType);

			lcRequestChoiceType.setQueryRequest(queryRequest);
			lcRequest.setLandedCostRequestChoice_type0(lcRequestChoiceType);
			LCStub.RequestTransportType requestTransType = new LCStub.RequestTransportType();
			requestTransType.setRequestAction("LandedCost");
			lcRequest.setRequest(requestTransType);
						

			/** ************UPSSE************************** */
			LCStub.AccessRequest upss = new LCStub.AccessRequest();
			upss.setAccessLicenseNumber(accesskey);
			upss.setPassword(password);
			upss.setUserId(username);
			/** ************UPSSE***************************** */

			LCStub.LandedCostResponse lcResponse = lcStub.ProcessLCRequest(lcRequest, upss);

			if (lcResponse != null && lcResponse.getLandedCostResponseChoice_type0() != null) {
				if (lcResponse.getLandedCostResponseChoice_type0().getQueryResponse() != null && lcResponse.getLandedCostResponseChoice_type0().getQueryResponse().getShipment() != null) {
					ProductResultType[] productResultType = lcResponse.getLandedCostResponseChoice_type0().getQueryResponse().getShipment().getProduct();
					if (productResultType != null & productResultType.length > 0 && productResultType[0] != null) {
						QuestionType[] questionType = productResultType[0].getQuestion();
						if (questionType != null && questionType.length > 0) {
							String questionNameFromResponse = questionType[0].getName();
							String questionTextFromResponse = questionType[0].getText();
							System.out.println("questionNameFromResponse: " + questionNameFromResponse);
							System.out.println("questionTextFromResponse: " + questionTextFromResponse);
							System.out.println("---------------------------------------");
						}
					}
				}
			}
			try {
				statusCode = lcResponse.getLandedCostResponseChoice_type0().getQueryResponse().getTransactionDigest();
				description = statusCode;
				updateResultsToFile(statusCode, description);
				System.out.println(" Success QueryResponse Status: " + statusCode);
			} catch (Exception e) {

			}

			try {
				statusCode = lcResponse.getLandedCostResponseChoice_type0().getEstimateResponse().getShipmentEstimate().getCurrencyCode();
				updateResultsToFile(statusCode, description);
				System.out.println(" SuccessTransaction Status:  EstimateResponse: " + statusCode);
			} catch (Exception e) {

			}
		} catch (Error avE) {
			LCStub.ErrorDetailType[] errors = avE.getFaultMessage().getErrorDetail();
			LCStub.ErrorDetailType aError = errors[0];
			LCStub.CodeType primaryError = aError.getPrimaryErrorCode();
			description = primaryError.getDescription();
			statusCode = primaryError.getCode();
			updateResultsToFile(statusCode, description);
			System.out.println("\nThe Error Response: Code=" + statusCode + " Decription=" + description);

		} catch (Exception e) {
			description = e.getMessage();
			statusCode = e.toString();

			if (e instanceof Error) {
				Errors errors = ((Error) e).getFaultMessage();
				ErrorDetailType[] errorDetailType = errors.getErrorDetail();
				CodeType codeTypeDetails = errorDetailType[0].getPrimaryErrorCode();
				statusCode = codeTypeDetails.getCode();
				description = codeTypeDetails.getDescription();
				System.out.println("Error code: " + statusCode);
				System.out.println("Error description: " + description);
				System.out.println("---------------------------------------");
			}
			updateResultsToFile(statusCode, description);
			e.printStackTrace();
		}
	}

	/**
	 * This method updates the XOLTResult.xml file with the received status and
	 * description
	 * 
	 * @param statusCode
	 * @param description
	 */
	private static void updateResultsToFile(String statusCode, String description) {
		BufferedWriter bw = null;
		try {
			File outFile = new File(props.getProperty(out_file_location));
			System.out.println("Output file deletion status: " + outFile.delete());
			outFile.createNewFile();
			System.out.println("Output file location: " + outFile.getCanonicalPath());
			bw = new BufferedWriter(new FileWriter(outFile));
			StringBuffer strBuf = new StringBuffer();
			strBuf.append("<ExecutionAt>");
			strBuf.append(Calendar.getInstance().getTime());
			strBuf.append("</ExecutionAt>\n");
			strBuf.append("<ToolOrWebServiceName>");
			strBuf.append(props.getProperty(tool_or_webservice_name));
			strBuf.append("</ToolOrWebServiceName>\n");
			strBuf.append("\n");
			strBuf.append("<ResponseStatus>\n");
			strBuf.append("\t<Code>");
			strBuf.append(statusCode);
			strBuf.append("</Code>\n");
			strBuf.append("\t<Description>");
			strBuf.append(description);
			strBuf.append("</Description>\n");
			strBuf.append("</ResponseStatus>");
			bw.write(strBuf.toString());
			bw.close();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (bw != null) {
					bw.close();
					bw = null;
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
}
