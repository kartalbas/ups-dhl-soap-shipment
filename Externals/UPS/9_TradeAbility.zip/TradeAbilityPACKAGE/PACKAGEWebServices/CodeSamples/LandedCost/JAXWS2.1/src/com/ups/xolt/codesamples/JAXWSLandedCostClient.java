/* 
 ** 
 ** Filename: JAXWSLandedCostClient.java 
 ** Authors: United Parcel Service of America
 ** 
 ** The use, disclosure, reproduction, modification, transfer, or transmittal 
 ** of this work for any purpose in any form or by any means without the 
 ** written permission of United Parcel Service is strictly prohibited. 
 ** 
 ** Confidential, Unpublished Property of United Parcel Service. 
 ** Use and Distribution Limited Solely to Authorized Personnel. 
 ** 
 ** Copyright 2010 United Parcel Service of America, Inc.  All Rights Reserved. 
 ** 
 */
package com.ups.xolt.codesamples;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.util.Calendar;
import java.util.List;
import java.util.Properties;

import javax.xml.ws.BindingProvider;

import com.ups.schema.xpci._1_0.auth.AccessRequest;
import com.ups.schema.xpci._1_0.error.CodeType;
import com.ups.schema.xpci._1_0.error.ErrorDetailType;
import com.ups.schema.xpci._1_0.error.Errors;
import com.ups.schema.xpci._1_0.lc.ChargesType;
import com.ups.schema.xpci._1_0.lc.Error;
import com.ups.schema.xpci._1_0.lc.LC;
import com.ups.schema.xpci._1_0.lc.LCRequestPortType;
import com.ups.schema.xpci._1_0.lc.LandedCostRequest;
import com.ups.schema.xpci._1_0.lc.LandedCostResponse;
import com.ups.schema.xpci._1_0.lc.ProductResultType;
import com.ups.schema.xpci._1_0.lc.ProductType;
import com.ups.schema.xpci._1_0.lc.QueryRequestType;
import com.ups.schema.xpci._1_0.lc.QuestionType;
import com.ups.schema.xpci._1_0.lc.RequestTransportType;
import com.ups.schema.xpci._1_0.lc.ShipmentType;
import com.ups.schema.xpci._1_0.lc.TariffInfoType;
import com.ups.schema.xpci._1_0.lc.ValueWithUnitsType;

public class JAXWSLandedCostClient {

	private static String accesskey;
	private static String username;
	private static String password;
	private static String url = "url";
	private static String out_file_location = "out_file_location";
	private static String tool_or_webservice_name = "tool_or_webservice_name";
	static Properties props = null;
	static {
		try {
			props = new Properties();
			props.load(new FileInputStream("./build.properties"));
			accesskey = props.getProperty("accesskey");
			username = props.getProperty("username");
			password = props.getProperty("password");
			url = props.getProperty("url");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void main(String args[]) throws Exception {
		String statusCode = null;
		String description = null;
		try {

			LC lcService = new LC();
			LCRequestPortType lcPort = lcService.getLCRequestPortTypePort();
			BindingProvider bp = (BindingProvider) lcPort;
			bp.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, url);

			LandedCostRequest lcRequest = new LandedCostRequest();
			RequestTransportType requestTransType = new RequestTransportType();
			requestTransType.setRequestAction("LandedCost");
			lcRequest.setRequest(requestTransType);

			
			  QueryRequestType queryRequest = new QueryRequestType();
			  ShipmentType shipment = new ShipmentType();
			  
			  shipment.setOriginCountryCode("US");
			  shipment.setOriginStateProvinceCode("");
			  shipment.setDestinationCountryCode("BE");
			  shipment.setDestinationStateProvinceCode("");
			  shipment.setTransportationMode("1");
			  
			  ChargesType freightChargeType = new ChargesType();
			  freightChargeType.setCurrencyCode("EUR");
			  freightChargeType.setMonetaryValue("10");
			  shipment.setFreightCharges(freightChargeType);
			  
			  ChargesType additionalInsuranceChargeType = new ChargesType();
			  additionalInsuranceChargeType.setCurrencyCode("EUR");
			  additionalInsuranceChargeType.setMonetaryValue("10");
			  shipment.setAdditionalInsurance(additionalInsuranceChargeType);
			  
			  List<ProductType> productTypeList = shipment.getProduct();
			  
			  ProductType productType = new ProductType(); TariffInfoType
			  tariffInfoType = new TariffInfoType();
			  tariffInfoType.setTariffCode("4901990000");
			  productType.setTariffInfo(tariffInfoType);
			  productType.setProductCountryCodeOfOrigin("US");
			  
			  ValueWithUnitsType value = new ValueWithUnitsType();
			  value.setValue("5"); productType.setQuantity(value);
			  
			  ValueWithUnitsType weightValue = new ValueWithUnitsType();
			  weightValue.setValue("2"); ValueWithUnitsType.UnitOfMeasure
			  unitofMeasure = new ValueWithUnitsType.UnitOfMeasure();
			  unitofMeasure.setUnitCode("kg");
			  unitofMeasure.setUnitDescription("");
			  weightValue.setUnitOfMeasure(unitofMeasure);
			  productType.setWeight(weightValue);
			  
			  ChargesType unitPriceChargesType = new ChargesType();
			  unitPriceChargesType.setCurrencyCode("EUR");
			  unitPriceChargesType.setMonetaryValue("5.5");
			  productType.setUnitPrice(unitPriceChargesType);
			  
			  productTypeList.add(productType);
			  
			  queryRequest.setShipment(shipment);
			  lcRequest.setQueryRequest(queryRequest);

		

			/** ************UPSSE************************** */
			AccessRequest upss = new AccessRequest();
			upss.setUserId(username);
			upss.setPassword(password);
			upss.setAccessLicenseNumber(accesskey);

			/** ************UPSSE***************************** */

			LandedCostResponse lcResponse = lcPort.processLCRequest(lcRequest, upss);
			try {
				List<ProductResultType> productResultTypeList = lcResponse.getQueryResponse().getShipment().getProduct();
				String questionNameFromResponse = "";
				String questionTextFromResponse = "";
				if (productResultTypeList != null && productResultTypeList.size() > 0) {
					ProductResultType productResultType = productResultTypeList.get(0);
					List<QuestionType> questionTypeList = productResultType.getQuestion();
					if (questionTypeList != null && questionTypeList.get(0) != null) {
						QuestionType questionType = questionTypeList.get(0);
						questionNameFromResponse = questionType.getName();
						questionTextFromResponse = questionType.getText();
						System.out.println("questionNameFromResponse: " + questionNameFromResponse);
						System.out.println("questionTextFromResponse: " + questionTextFromResponse);
					}

				}
				updateResultsToFile(questionNameFromResponse, questionTextFromResponse);

			} catch (Exception e) {

			}
			try {
				statusCode = lcResponse.getEstimateResponse().getShipmentEstimate().getCurrencyCode();
				updateResultsToFile(statusCode, description);
				System.out.println(" SuccessTransaction Status:  EstimateResponse: " + statusCode);
			} catch (Exception e) {

			}
			
			

		} catch (Error avE) {
			Errors errs = avE.getFaultInfo();
			List<ErrorDetailType> errDetailList = errs.getErrorDetail();
			ErrorDetailType aError = errDetailList.get(0);

			CodeType primaryError = aError.getPrimaryErrorCode();
			description = primaryError.getDescription();
			statusCode = primaryError.getCode();
			updateResultsToFile(statusCode, description);
			System.out.println("\nThe Error Response: Code=" + statusCode + " Decription=" + description);

		} catch (Exception e) {
			description = e.getMessage();
			statusCode = e.toString();

			if (e instanceof Error) {
				List<ErrorDetailType> errorDetailList = ((Error) e).getFaultInfo().getErrorDetail();
				if (errorDetailList != null) {
					ErrorDetailType errorDetails = errorDetailList.get(0);
					if (errorDetails != null) {
						CodeType codeDetails = errorDetails.getPrimaryErrorCode();
						statusCode = codeDetails.getCode();
						description = codeDetails.getDescription();
						System.out.println("Error code: " + statusCode);
						System.out.println("Error description: " + description);
						System.out.println("---------------------------------------");
					}
				}

			}
			updateResultsToFile(statusCode, description);
			e.printStackTrace();
		}

	}

	/**
	 * This method updates the XOLTResult.xml file with the received status and
	 * description
	 * 
	 * @param statusCode
	 * @param description
	 */
	private static void updateResultsToFile(String questionNameFromResponse, String questionTextFromResponse) {
		BufferedWriter bw = null;
		try {
			File outFile = new File(props.getProperty(out_file_location));
			System.out.println("Output file deletion status: " + outFile.delete());
			outFile.createNewFile();
			System.out.println("Output file location: " + outFile.getCanonicalPath());
			bw = new BufferedWriter(new FileWriter(outFile));
			StringBuffer strBuf = new StringBuffer();
			strBuf.append("<ExecutionAt>");
			strBuf.append(Calendar.getInstance().getTime());
			strBuf.append("</ExecutionAt>\n");
			strBuf.append("<ToolOrWebServiceName>");
			strBuf.append(props.getProperty(tool_or_webservice_name));
			strBuf.append("</ToolOrWebServiceName>\n");
			strBuf.append("\n");
			strBuf.append("<ResponseStatus>\n");
			strBuf.append("\t<Status>");
			strBuf.append(questionNameFromResponse);
			strBuf.append("</Status>\n");
			strBuf.append("\t<Details>");
			strBuf.append(questionTextFromResponse);
			strBuf.append("</Details>\n");
			strBuf.append("</ResponseStatus>");
			bw.write(strBuf.toString());
			bw.close();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (bw != null) {
					bw.close();
					bw = null;
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
}
