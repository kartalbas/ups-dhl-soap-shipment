using System;
using System.Collections.Generic;
using System.Text;
using ImportComplianceWSSample.ImportComplianceWebReference;

namespace ImportComplianceWSSample
{
    class ImportComplianceClient
    {
        static void Main()
        {
            IC icService = new IC();
            ImportComplianceRequest icRequest = new ImportComplianceRequest();
            RequestTransportType request = new RequestTransportType();
            request.RequestAction="ImportCompliance";
            icRequest.Request=request;
            icRequest.DestinationCountryCode="Your destination country code";
            icRequest.OriginCountryCode = "Your origin country code";

           
            ProductType prodType = new ProductType();
            prodType.ProductName = "Required product name";
            prodType.ProductCountryCodeOfOrigin = "Your origin country code";

          


            TariffInfoType trfInfoType = new TariffInfoType();
           trfInfoType.TariffCode="Required tariff code";
          
            prodType.TariffInfo=trfInfoType;
            ProductType[] productType = { prodType };
            icRequest.Product = productType;

            AccessRequest accessRequest = new AccessRequest();
            accessRequest.UserId = "Your user id";
            accessRequest.Password = "Your password";
           accessRequest.AccessLicenseNumber = "Your access license number";

           
            icService.AccessRequestValue = accessRequest;

            System.Net.ServicePointManager.CertificatePolicy = new TrustAllCertificatePolicy();

            //--------------------------------
         
            Console.WriteLine("----Start Request ToString---------------------");
            Console.WriteLine(icRequest.ToString());
            Console.WriteLine("-----End Request ToString--------------------");
            Console.WriteLine("");

            try
            {

                Console.WriteLine("-----Start Response Process--------------------");
                ImportComplianceResponse icResponse = icService.ProcessICRequest(icRequest);
                Console.WriteLine("This is a success transaction=" + icResponse.TransactionInfo.Date);
                TariffLevelRateType[] trates = icResponse.TariffLevelRate;

                Console.WriteLine("Total on TariffLevelRate List = " + trates.Length);

                TariffLevelRateType aRest = trates[0];

                RateType arate = aRest.Rate;
                KeyValuePairType[] results = arate.Result;

                Console.WriteLine("Total number of  results = " + results.Length);
                KeyValuePairType rtl = results[0];

                Console.WriteLine("Key=" + rtl.Key);
                Console.WriteLine("Value=" + rtl.Value);

                RateTypePreferrentialRate[] prefs = arate.PreferrentialRate;
                Console.WriteLine("Total number of PreferrentialRate = " + prefs.Length);


                Console.WriteLine("-------------------------");
                Console.WriteLine("");
            }
            catch (System.Web.Services.Protocols.SoapException ex)
            {
                Console.WriteLine("");
                Console.WriteLine("--------- ImportComplianceResponse Web Service returns error----------------");
                Console.WriteLine("---------\"Hard\" is user error \"Transient\" is system error----------------");
                Console.WriteLine("SoapException Message= " + ex.Message);
                Console.WriteLine("");
                Console.WriteLine("SoapException Category:Code:Message= " + ex.Detail.LastChild.InnerText);
                Console.WriteLine("");
                Console.WriteLine("SoapException XML String for all= " + ex.Detail.LastChild.OuterXml);
                Console.WriteLine("");
                Console.WriteLine("SoapException StackTrace= " + ex.StackTrace);
                Console.WriteLine("-------------------------");
                Console.WriteLine("");
            }
            catch (Exception ex)
            {
                Console.WriteLine("");
                Console.WriteLine("-------------------------");
                Console.WriteLine(" Generaal Exception= " + ex.Message);
                Console.WriteLine(" Generaal Exception-StackTrace= " + ex.StackTrace);
                Console.WriteLine("-------------------------");

            }
            finally
            {
                Console.ReadKey();
            }



        }
    }
}
