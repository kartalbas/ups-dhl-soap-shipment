<?php

  //Configuration
  $access = " Add License Key Here";
  $userid = " Add User Id Here";
  $passwd = " Add Password Here";
  $wsdl = " Add Wsdl File Here ";
  $operation = "ProcessICRequest";
  $endpointurl = ' Add URL Here';
  $outputFileName = "XOLTResult.xml";

  function processICRequest()
  {
      //create soap request
      $action['RequestAction'] = 'ImportCompliance';
      $request['Request'] = $action;

      $request['DestinationCountryCode'] = 'US';
	  $request['OriginCountryCode'] = 'CR';
	  $request['Product'] = array
	  (
	    	array
	    	(
	    		'ProductCountryCodeOfOrigin' => 'CR',
	    		'TariffInfo' => array
	    		(
	    			'TariffCode' => '4010110000'
	    		)
	    	)
	  );

      echo "Request.......\n";
      print_r($request);
      echo "\n\n";
      return $request;
  }

  try
  {

    $mode = array
    (
         'soap_version' => 'SOAP_1_1',  // use soap 1.1 client
         'trace' => 1
    );

    // initialize soap client
  	$client = new SoapClient($wsdl , $mode);

  	//set endpoint url
  	$client->__setLocation($endpointurl);


    //create soap header
    $auth['UserId'] = $userid;
    $auth['Password'] = $passwd;
    $auth['AccessLicenseNumber'] = $access;


    $header = new SoapHeader('http://www.ups.com/schema/xpci/1.0/auth','AccessRequest',$auth);
    $client->__setSoapHeaders($header);


    //get response
  	$resp = $client->__soapCall($operation ,array(processICRequest()));

    //get status
    echo "Response Status: ". $resp->TariffLevelRate->Rate->Result[0]->Value . "\n";

    //save soap request and response to file
    $fw = fopen($outputFileName , 'w');
    fwrite($fw , "Request: \n" . $client->__getLastRequest() . "\n");
    fwrite($fw , "Response: \n" . $client->__getLastResponse() . "\n");
    fclose($fw);

  }
  catch(Exception $ex)
  {
  	print_r ($ex);
  }

?>
