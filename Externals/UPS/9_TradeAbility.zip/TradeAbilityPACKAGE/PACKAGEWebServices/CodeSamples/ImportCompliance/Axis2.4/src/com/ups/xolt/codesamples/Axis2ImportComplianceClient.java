/*
 **
 ** Filename: Axis2ImportComplianceClient.java
  ** Authors: United Parcel Service of America
 **
 ** The use, disclosure, reproduction, modification, transfer, or transmittal
 ** of this work for any purpose in any form or by any means without the
 ** written permission of United Parcel Service is strictly prohibited.
 **
 ** Confidential, Unpublished Property of United Parcel Service.
 ** Use and Distribution Limited Solely to Authorized Personnel.
 **
 ** Copyright 2009 United Parcel Service of America, Inc.  All Rights Reserved.
 **
 */
package com.ups.xolt.codesamples;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.net.URL;
import java.util.Calendar;
import java.util.Properties;

import com.ups.www.schema.xpci._1_0.ic.ICStub;
import com.ups.www.schema.xpci._1_0.ic.ICStub.ProductType;
import com.ups.www.schema.xpci._1_0.ic.Error;

public class Axis2ImportComplianceClient {

	private static String url;
	private static String accesskey;
	private static String username;
	private static String password;
	private static String out_file_location = "out_file_location";
	private static String tool_or_webservice_name = "tool_or_webservice_name";
	static Properties props = null;
	static{
		try{
        	props = new Properties();
        	props.load(new FileInputStream("./build.properties"));
	  		url = props.getProperty("url");
	  		accesskey = props.getProperty("accesskey");
	  		username = props.getProperty("username");
	  		password = props.getProperty("password");
        }
        catch(Exception e){
        	e.printStackTrace();
        }
	}
	public static void main(String args[])throws Exception {
		String statusCode = null;
		String description = null;
		try {
			ICStub icStub = new ICStub(url);
			ICStub.ImportComplianceRequest icRequest = new ICStub.ImportComplianceRequest();
			ICStub.RequestTransportType request = new ICStub.RequestTransportType();
			request.setRequestAction("ImportCompliance");
			icRequest.setRequest(request);
		    icRequest.setDestinationCountryCode("US");
		    icRequest.setOriginCountryCode("CR");
		    icRequest.setRequest(request);
		    ICStub.ProductType prodType = new ICStub.ProductType();
		    ICStub.TariffInfoType trInfoType = new ICStub.TariffInfoType();

		    trInfoType.setTariffCode("4010110000");
		    prodType.setTariffInfo(trInfoType);
		    prodType.setProductCountryCodeOfOrigin("CR");
		    ProductType[] pType = new ProductType[1];
		    pType[0] = prodType;
		    icRequest.setProduct(pType);

			/** ************UPSSE***************************/
			ICStub.AccessRequest upss = new ICStub.AccessRequest();
			upss.setAccessLicenseNumber(accesskey);
			upss.setPassword(password);
			upss.setUserId(username);
			/** ************UPSSE******************************/

			ICStub.ImportComplianceResponse icResponse = icStub.ProcessICRequest(icRequest, upss);
			if (null != icResponse)
			{
				updateResultsToFile("1", "Success");
			}

			System.out.println("Success Transaction Status: " + icResponse.getTransactionInfo().getDate());

		} catch (Error avE) {
			ICStub.ErrorDetailType[] errors = avE.getFaultMessage().getErrorDetail();
			ICStub.ErrorDetailType aError = errors[0];

			ICStub.CodeType primaryError = aError.getPrimaryErrorCode();
			description = primaryError.getDescription();
			statusCode = primaryError.getCode();
			updateResultsToFile(statusCode, description);
			System.out.println("\nThe Error Response: Code=" + statusCode + " Decription=" + description);

		}  catch (Exception e) {
			description=e.getMessage();
			statusCode=e.toString();
			updateResultsToFile(statusCode, description);
			e.printStackTrace();
		}

	}
	/**
     * This method updates the XOLTResult.xml file with the received status and description
     * @param statusCode
     * @param description
     */
	private static void updateResultsToFile(String statusCode, String description){
    	BufferedWriter bw = null;
    	try{
     		File outFile = new File(props.getProperty(out_file_location));
    		System.out.println("Output file deletion status: " + outFile.delete());
    		outFile.createNewFile();
    		System.out.println("Output file location: " + outFile.getCanonicalPath());
    		bw = new BufferedWriter(new FileWriter(outFile));
    		StringBuffer strBuf = new StringBuffer();
    		strBuf.append("<ExecutionAt>");
    		strBuf.append(Calendar.getInstance().getTime());
    		strBuf.append("</ExecutionAt>\n");
    		strBuf.append("<ToolOrWebServiceName>");
    		strBuf.append(props.getProperty(tool_or_webservice_name));
    		strBuf.append("</ToolOrWebServiceName>\n");
    		strBuf.append("\n");
    		strBuf.append("<ResponseStatus>\n");
    		strBuf.append("\t<Code>");
    		strBuf.append(statusCode);
    		strBuf.append("</Code>\n");
    		strBuf.append("\t<Description>");
    		strBuf.append(description);
    		strBuf.append("</Description>\n");
    		strBuf.append("</ResponseStatus>");
    		bw.write(strBuf.toString());
    		bw.close();
    	}catch (Exception e) {
			e.printStackTrace();
		}finally{
			try{
				if (bw != null){
					bw.close();
					bw = null;
				}
			}catch (Exception e) {
				e.printStackTrace();
			}
		}
    }
}
